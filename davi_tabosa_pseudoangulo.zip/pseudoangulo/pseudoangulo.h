#include <iostream>
#include "vec2.h"
#include <cmath>
double PAngleBetween(const Vec2,const Vec2); //pseudoangle between two 2D vectors
double PAngle(const Vec2); //pseudoangle between this 2D vector and a VEC2_RIGHT
