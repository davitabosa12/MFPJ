#pragma once
#include <vector>
#include "vec2.h"
class AABB;
class OBB;
class Circle;
